package com.example.tamzid.notes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateAndDelete extends AppCompatActivity {

    EditText e;
    Button b,d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_and_delete);

        e = (EditText) findViewById(R.id.udEditText);
        b = (Button) findViewById(R.id.update);
        d = (Button) findViewById(R.id.delete);

        final int rec_pos = getIntent().getIntExtra("MyKEY", 999);

        final DatabaseFunction obj = new DatabaseFunction(getApplicationContext());

        e.setText(obj.fetch_note(rec_pos+1));
        e.setSelection(e.getText().length());

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.updateNote((rec_pos+1), e.getText().toString());
                Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplication(), Notes.class);
                startActivity(intent);
            }
        });

        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.deleteNote(obj.fetch_note(rec_pos+1));
                Toast.makeText(getApplicationContext(), "Deleted", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplication(), Notes.class);
                startActivity(intent);

            }
        });
    }
}
